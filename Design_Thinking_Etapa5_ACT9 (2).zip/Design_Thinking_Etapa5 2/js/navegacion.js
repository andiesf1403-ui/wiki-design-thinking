/* Wiki Design · Design Thinking — Etapa 5: navegación e interactividad */
document.addEventListener("DOMContentLoaded", function () {
    var botonSubir = document.getElementById("subir");
    var enlacesMenu = document.querySelectorAll(".navegacion a, .barra-lateral a");
    var ids = ["que-es", "etapas", "ejemplo", "recursos", "colabora", "acerca"];
    var pendiente = false;

    /* 1. Botón "volver arriba" y resaltado de la sección actual */
    function actualizar() {
        pendiente = false;
        var y = window.scrollY || document.documentElement.scrollTop;
        botonSubir.classList.toggle("visible", y > 500);

        var actual = "inicio";
        var referencia = window.innerHeight * 0.35;
        ids.forEach(function (id) {
            var el = document.getElementById(id);
            if (el && el.getBoundingClientRect().top <= referencia) { actual = id; }
        });
        if (window.innerHeight + y >= document.documentElement.scrollHeight - 4) { actual = "acerca"; }

        enlacesMenu.forEach(function (a) {
            var activo = a.getAttribute("href") === "#" + actual;
            a.classList.toggle("activo", activo);
            if (activo) { a.setAttribute("aria-current", "true"); } else { a.removeAttribute("aria-current"); }
        });
    }
    window.addEventListener("scroll", function () {
        if (!pendiente) { pendiente = true; window.requestAnimationFrame(actualizar); }
    }, { passive: true });
    window.addEventListener("resize", actualizar);
    actualizar();

    /* 2. Búsqueda dentro de la página, con mensaje y desplazamiento al primer resultado */
    var formulario = document.getElementById("formulario-busqueda");
    var campo = document.getElementById("buscar");
    var mensaje = document.getElementById("mensaje-busqueda");

    function limpiar() {
        document.querySelectorAll(".resultado-busqueda").forEach(function (s) {
            s.classList.remove("resultado-busqueda");
        });
        mensaje.hidden = true;
        mensaje.textContent = "";
    }

    formulario.addEventListener("submit", function (evento) {
        evento.preventDefault();
        limpiar();
        var palabra = campo.value.toLowerCase().trim();
        if (palabra === "") { return; }

        var encontrados = [];
        document.querySelectorAll("main section").forEach(function (s) {
            if (s.textContent.toLowerCase().indexOf(palabra) !== -1) {
                s.classList.add("resultado-busqueda");
                encontrados.push(s);
            }
        });

        mensaje.hidden = false;
        if (encontrados.length === 0) {
            mensaje.textContent = "No se encontraron resultados para “" + campo.value.trim() + "”.";
        } else {
            mensaje.textContent = encontrados.length + (encontrados.length === 1 ? " apartado coincide" : " apartados coinciden") +
                " con “" + campo.value.trim() + "”. Borra la búsqueda para quitar el resaltado.";
            encontrados[0].scrollIntoView({ behavior: "smooth", block: "center" });
        }
    });

    campo.addEventListener("input", function () { if (campo.value === "") { limpiar(); } });
    campo.addEventListener("keydown", function (e) { if (e.key === "Escape") { campo.value = ""; limpiar(); } });

    /* 3. Al llegar con un enlace interno, el destino recibe el foco (útil con teclado) */
    document.addEventListener("click", function (e) {
        var a = e.target.closest ? e.target.closest('a[href^="#"]') : null;
        if (!a || a.getAttribute("href") === "#") { return; }
        var destino = document.getElementById(a.getAttribute("href").slice(1));
        if (destino) {
            if (!destino.hasAttribute("tabindex")) { destino.setAttribute("tabindex", "-1"); }
            setTimeout(function () { destino.focus({ preventScroll: true }); }, 350);
        }
    });
});
